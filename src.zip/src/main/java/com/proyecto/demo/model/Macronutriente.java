package com.proyecto.demo.model;

public enum Macronutriente {
    PROTEINA,
    CARBOHIDRATO,
    GRASA
}