package com.proyecto.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanificadorMenuApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanificadorMenuApplication.class, args);
	}

}
