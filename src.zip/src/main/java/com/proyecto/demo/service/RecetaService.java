package com.proyecto.demo.service;

import com.proyecto.demo.model.Receta;
import com.proyecto.demo.model.IngredienteReceta;
import com.proyecto.demo.repository.RecetaRepository;
import com.proyecto.demo.repository.IngredienteRecetaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.HashSet;
import java.util.List;

@Service
@Transactional
public class RecetaService {

    private final RecetaRepository recetaRepository;

    // Se deja inyectado por si lo usas después; no causa error si no se usa
    @SuppressWarnings("unused")
    private final IngredienteRecetaRepository ingredienteRecetaRepository;

    public RecetaService(RecetaRepository recetaRepository,
                         IngredienteRecetaRepository ingredienteRecetaRepository) {
        this.recetaRepository = recetaRepository;
        this.ingredienteRecetaRepository = ingredienteRecetaRepository;
    }

    // Crear receta con ingredientes asociados
    public Receta crearReceta(Receta receta) {
        if (recetaRepository.existsByNombreIgnoreCase(receta.getNombre())) {
            throw new IllegalArgumentException("Ya existe una receta con el nombre: " + receta.getNombre());
        }

        // Validar que no se repitan ingredientes y amarrar la relación inversa
        if (receta.getIngredientesReceta() != null) {
            Set<Long> ids = new HashSet<>();
            for (IngredienteReceta ir : receta.getIngredientesReceta()) {
                Long ingredienteId = (ir.getIngrediente() != null) ? ir.getIngrediente().getId() : null;
                if (ingredienteId != null && !ids.add(ingredienteId)) {
                    throw new IllegalArgumentException(
                        "El ingrediente con ID " + ingredienteId + " está repetido en la receta."
                    );
                }
                ir.setReceta(receta);
            }
        }

        return recetaRepository.save(receta);
    }

    // Listar todas
    public List<Receta> listarRecetas() {
        return recetaRepository.findAll();
    }

    // Obtener una receta
    public Receta obtenerReceta(Long id) {
        return recetaRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Receta no encontrada con ID: " + id));
    }

    // Actualizar receta
    public Receta actualizarReceta(Long id, Receta recetaActualizada) {
        Receta receta = obtenerReceta(id);

        receta.setNombre(recetaActualizada.getNombre());
        receta.setDescripcion(recetaActualizada.getDescripcion());

        // No sobrescribir con null si no viene en la actualización
        if (recetaActualizada.getMacronutriente() != null) {
            receta.setMacronutriente(recetaActualizada.getMacronutriente());
        }

        // Actualizar ingredientes si vienen en el cuerpo
        if (recetaActualizada.getIngredientesReceta() != null) {
            receta.getIngredientesReceta().clear();
            for (IngredienteReceta ir : recetaActualizada.getIngredientesReceta()) {
                ir.setReceta(receta); // asegurar lado inverso
                receta.getIngredientesReceta().add(ir);
            }
        }

        return recetaRepository.save(receta);
    }

    // Eliminar receta y sus relaciones
    public void eliminarReceta(Long id) {
        Receta receta = obtenerReceta(id);
        recetaRepository.delete(receta);
    }
}
